package pgmsPkg;

import java.util.Optional;

public class Pgm1 {

	public static void main(String[] args) {
		Optional<String>str=Optional.empty();
		System.out.println(str.filter(s->s.equals(null)));

	}

}
