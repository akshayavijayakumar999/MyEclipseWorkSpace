package pgmsPkg;

public class Main {
	static int power(int x,int y)
	{
		if(y==0)
		return 1;
		int answer=x;
		int increment=x;
		int i,j;
		for(i=1;i<y;i++)
		{
			for(j=1;j<x;j++)
			{
				answer +=increment;
			}
			increment=answer;
		}
		return increment;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x=2;
		int y=3;
		System.out.printf("%d",power(x,y));
	}

}
