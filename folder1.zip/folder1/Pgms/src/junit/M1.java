package junit;

import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.List;

import org.junit.Test;

public class M1 {

	@Test
	public void everyItemGreaterThan1() {
		
		List<Integer> list=Arrays.asList(5,2,4);
		assertThat(list,everyItem(greaterThan(1)));
		assertThat(list,isItem(greaterThan(1)));
		assertThat(list,items(greaterThan(1)));
	
		
	}

}
