package july8;



public class Ust {
	public static void main(String[] args){  
		
	HRmanagement e1=new HRmanagement("1","Akshaya",2);
	HRmanagement.info(1000,"UST");
	e1.calSal();
	e1.print();
	
	HRmanagement e2=new HRmanagement("2","Akshara",0);
	e2.calSal();
	e2.print();
	HRmanagement.info(2000,"INFOSYS");
	HRmanagement e3=new HRmanagement("3","Kaveri",4);
	e3.calSal();
	e3.print();
	
	}	
}
