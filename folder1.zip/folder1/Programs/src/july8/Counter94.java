package july8;

public class Counter94 {
	
	static int count=0;//will get memory only once and retain its value  
	  
	Counter94(){ 
		count++;//incrementing the value of static variable  
		System.out.println(count);  
		}  
		  
		public static void main(String args[]){  
		//creating objects  
			Counter94 c1=new Counter94();  
			Counter94 c2=new Counter94();  
			Counter94 c3=new Counter94();  
	}


}
