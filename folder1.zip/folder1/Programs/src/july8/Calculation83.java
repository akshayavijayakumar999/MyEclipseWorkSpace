package july8;

public class Calculation83 {
	
	void fact(int  n){  
		  int fact=1;  
		  for(int i=1;i<=n;i++){  
		   fact=fact*i;  
		  }  
		 System.out.println("factorial is "+fact);  
		}  
		public static void main(String args[]){  
			 new Calculation83().fact(5);//calling method with anonymous object  

		}


}
