package july8;

public class Passenger {

	String name;
	int amount;
	String dest;
	String mode;
	int num;
	int pkg;Passenger(String na,int a,String d,String m,int n)
	{
		name=na;
		amount=a;
		dest=d;
		mode=m;
		num=n;
		
	}
		
	int calPkg()
	{
	
		pkg=num*amount;
		return pkg;
	}
	

	void payslip()
	{
		System.out.println("**************************");
		System.out.println("Name: "+name);
		System.out.println("No of passengers:"+num);
		System.out.println("Destination:"+dest);
		System.out.println("Mode of transport: "+mode);
		System.out.println("Package Amount:"+calPkg());
		System.out.println("**************************");
	}

}