package july8;

public class Student {
	int id;
	String name;
	
	void input(int i,String n)
	{
		id=1;
		name=n;
	}

}
