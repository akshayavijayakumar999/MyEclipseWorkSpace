package july8;

public class ClassTestStudent1 {
	public static void main(String args[]) { 
		Student s1=new Student();
		s1.id=10;
		s1.name="Akshaya";
		
		Student s2=new Student();
		s2.id=11;
		s2.name="Anu";
		
		System.out.println("id1:"+s1.id);
		System.out.println("name1:"+s1.name);
		
		System.out.println("id2:"+s2.id);
		System.out.println("name2:"+s2.name);
	
	// Using constructor
		Class c=new Class(1,"Arya");
		System.out.println("Division : "+c.div);
		System.out.println("Teacher Name: "+c.Teacher_name);
		
	//Using method
		Student s3=new Student();
		s3.input(12, "Akshara");
		System.out.println("id3:"+s3.id);
		System.out.println("name3:"+s3.name);
	}

}
