package july8;

public class Area {

	public static void main(String args[]) { 
		Rectangle a=new Rectangle(5,10);
		a.area();
	}
}
