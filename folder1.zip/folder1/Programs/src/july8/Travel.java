package july8;

import java.util.Scanner;

public class Travel {
	public static void main(String[] args){ 

		int n,no;
		char c;
		String na;

		Scanner s=new Scanner(System.in);
		do {
			System.out.println("1. MUNNAR / MODE:BUS / AMOUNT:10000");
			System.out.println("2. DELHI / MODE:RAILWAY / AMOUNT:20000");
			System.out.println("3. US / MODE:AIRLINE / AMOUNT:300000");
			System.out.println("SELECT YOUR CHOICE : ");
			n = s.nextInt();
			switch(n)
			{

			default:System.out.println("Invalid Choice");
			break;


			case 1:
				System.out.println("Enter your name:");
				na=s.next();
				System.out.println("Enter your number of passengers :");
				no=s.nextInt();
				Passenger p=new Passenger(na,10000,"Munnar","Bus",no);
				p.payslip();
				break;
			case 2:
				System.out.println("Enter your name:");
				na=s.next();
				System.out.println("Enter your number of passengers :");
				no=s.nextInt();
				Passenger p1=new Passenger(na,20000,"Delhi","Railway",no);
				p1.payslip();
				break;

			case 3:
				System.out.println("Enter your name:");
				na=s.next();
				System.out.println("Enter your number of passengers :");
				no=s.nextInt();
				Passenger p2=new Passenger(na,300000,"UK","AirLine",no);
				p2.payslip();
				break;

			}

			System.out.println("Do you want to continue?(Y/N): ");	
			c=s.next().charAt(0);   
		}
		while(c=='y'||c=='Y');
		s.close();

	
		
		
		
	}

}
