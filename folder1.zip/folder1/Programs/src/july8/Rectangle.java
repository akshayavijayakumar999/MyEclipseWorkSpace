package july8;

public class Rectangle {
	int l,b;
	int Area;
	Rectangle(int x,int y)
	{
		l=x;
		b=y;
	}

	void area ()
	{
		System.out.println("Area :" +(l*b));
	}
}
