package july8;

 class Student92 {
	int rollno;//instance variable  
	   String name;  
	   static String college ="ITS";//static variable  
	   //constructor  
	   Student92(int r, String n){  
	   rollno = r;  
	   name = n;  
	   }  
	   //method to display the values  
	   void display (){System.out.println(rollno+" "+name+" "+college);}
}  
//Test class to show the values of objects  
public class TestStaticVariable1{  
public static void main(String args[]){  
	Student92 s1 = new Student92(111,"Karan");  
	Student92 s2 = new Student92(222,"Aryan");
//we can change the college of all objects by the single line of code  
//Student.college="BBDIT";  
s1.display();  
s2.display();  
}  


}
