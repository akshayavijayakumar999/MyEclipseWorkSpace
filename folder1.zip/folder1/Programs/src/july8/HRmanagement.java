package july8;

public class HRmanagement {
	
	
		
		String Emp_no;
		String Emp_name;
		double sal;
		int leave;
		static double basic_sal;
		static String company;
		
		
		HRmanagement(String n,String e,int l)
		{
			 Emp_no=n;
			 Emp_name=e;
			 leave=l;
		}
		
		static void info(double b,String c)
		{
			basic_sal=b;	
			company=c;
		}

		void calSal()
		{
			int d=31-leave;
			sal=basic_sal*d;
			
		}
		
		void print()
		{
			System.out.println("******PAY SLIP***********");
			System.out.println();
			System.out.println("Employee Number: " +Emp_no);
			System.out.println("Employee Name: " +Emp_name);
			System.out.println("No of leaves taken: " +leave);
			System.out.println("Company : " +company);
			System.out.println("Basic Salary : " +basic_sal);
			System.out.println("Salary : " +sal);
			System.out.println();
			System.out.println("*****************");
		}
		
		
	}




