package july8;

public class Class {
	
	int div;
	String Teacher_name;
	
	Class(int div,String n)
	{
		div=1;
		Teacher_name=n;
	}


}
