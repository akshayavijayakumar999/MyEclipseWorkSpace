package july8;

public class Destination {
	String dest_name;
	int dest_amount;

	Destination(String n,int a)
	{
		dest_name=n;
		dest_amount=a;
		
	}
}
