package july14;

import java.util.Scanner;

public class Armstrong {
	public static void main(String[] args)   
	{ 
		int temp,d,s=0;
	Scanner sc=new Scanner(System.in);
	System.out.print("Enter the rows: ");
	int n=sc.nextInt();
	temp=n;
	while(n>0)
	{
		d=n%10;
		n=n/10;
		s=s+(d*d*d);
		
	}
	if(s==temp)
	
		System.out.println(temp + " is an Armstrong Number");
	else
		
		System.out.println(temp + " is not an Armstrong Number");
	sc.close();
	
}
}
