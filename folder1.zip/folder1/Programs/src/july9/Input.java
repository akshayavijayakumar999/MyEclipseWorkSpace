package july9;

public class Input {
	public static void main(String[] args) {
		
		char v='a';
		int a=v;
		
		System.out.println(a);
	}


}
