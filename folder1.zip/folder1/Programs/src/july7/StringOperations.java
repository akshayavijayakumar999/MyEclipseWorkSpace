package july7;

import java.util.Scanner;

public class StringOperations {


	public int  leng(String s1)
	{

		return (s1.length());
	}

	public String  con(String s1,String s2 )
	{

		return (s1.concat(s2));
	}

	public int equal(String s1,String s2)
	{

		if (s1.equals(s2))

			return 1;
		else
			return 0;
	}

	public StringBuilder  rev(String s1)
	{
		StringBuilder sb=new StringBuilder(s1); 
		return (sb.reverse());
	}

	public char at(String s1,int index)
	{

		char result = s1.charAt(index);
		return result;
	}

	public static void main(String[] args) {

		String st1,st2,p;
		StringBuilder d;
		int f,g;
		int len;
		int n;
		char c;

		// Create Scanner object
		Scanner s = new Scanner(System.in);
		StringOperations ca=new StringOperations();
		do {
			System.out.println("***********");
			System.out.println("1. String Length ");
			System.out.println("2. String Conactenation");
			System.out.println("3. Equal or not");
			System.out.println("4. String Reverse");
			System.out.println("5. Find character");
			System.out.println("SELECT YOUR CHOICE : ");
			n = s.nextInt();

			switch(n)
			{

			default:System.out.println("Invalid Choice");
			break;


			case 1:
				System.out.println("Enter the String: ");
				st1 = s.next();

				len=ca.leng(st1);
				System.out.println("Length : " +len);
				break;
			case 2:
				System.out.println("Enter the first String: ");
				st1 = s.next();
				System.out.println("Enter the first String: ");
				st2 = s.next();

				p=ca.con(st1, st2);
				System.out.println("Concatenated String : " +p);
				break;
			case 3:
				System.out.println("Enter the first String: ");
				st1 = s.next();
				System.out.println("Enter the Second String: ");
				st2 = s.next();
				f=ca.equal(st1, st2);
				if(f==1)
					System.out.println("Strings are equal");
				else
					System.out.println("Strings are not equal");	
				break;
			case 4:
				System.out.println("Enter the String: ");
				st1 = s.next();

				d=ca.rev(st1);
				System.out.println("Reverse: " +d);
				break;
			case 5:System.out.println("Enter the String: ");
			st1 = s.next();
			System.out.println("Enter the index: ");
			int e = s.nextInt();
			char in=ca.at(st1, e);
			System.out.println("character  at "+(e+1)+" th position is "+ in);

			break;
			}
			System.out.println("Do you want to continue?(Y/N): ");	
			c=s.next().charAt(0);   
		}
		while(c=='y'||c=='Y');
		s.close();

	}


}
