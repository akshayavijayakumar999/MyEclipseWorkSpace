package july7;

import java.util.Scanner;

public class Calculator1 {

	public double  add(double a,double b)
	{
		double e=a+b;
		return e;
	}

	public double  sub(double a,double b)
	{
		double e=a-b;
		return e;
	}

	public double  mult(double a,double b)
	{
		double e=a*b;
		return e;
	}

	public double  div(double a,double b)
	{
		double e=a/b;
		return e;
	}

	public static void main(String[] args) {

		double n1,n2,s1,d,p;
		int n;
		char c;

		// Create Scanner object
		Scanner s = new Scanner(System.in);
		Calculator1 ca=new Calculator1();
		do {
			System.out.println("CALCULATOR");
			System.out.println("1. ADDITION");
			System.out.println("2. SUBTRACTION");
			System.out.println("3. MULTIPLICATION");
			System.out.println("4. DIVISION");
			System.out.println("SELECT YOUR CHOICE : ");
			n = s.nextInt();

			switch(n)
			{

			default:System.out.println("Invalid Choice");
			break;


			case 1:
				System.out.println("Enter the two numbers: ");
				n1 = s.nextDouble();
				n2 = s.nextDouble();
				s1=ca.add(n1, n2);
				System.out.println("Sum: " +s1);
				break;
			case 2:
				System.out.println("Enter the two numbers: ");
				n1 = s.nextDouble();
				n2 = s.nextDouble();
				d=ca.sub(n1, n2);
				System.out.println("Difference : " +d);
				break;
			case 3:
				System.out.println("Enter the two numbers: ");
				n1 = s.nextDouble();
				n2 = s.nextDouble();
				p=ca.mult(n1, n2);
				System.out.println("Product : " +p);
				break;
			case 4:
				System.out.println("Enter the two numbers: ");
				n1 = s.nextDouble();
				n2 = s.nextDouble();
				d=ca.div(n1, n2);
				System.out.println("Dividend: " +d);
				break;

			}

			System.out.println("Do you want to continue?(Y/N): ");	
			c=s.next().charAt(0);   
		}
		while(c=='y'||c=='Y');
		s.close();

	}


}
