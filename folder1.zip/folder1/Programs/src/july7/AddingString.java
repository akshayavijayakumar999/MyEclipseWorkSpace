package july7;

import java.util.Scanner;

public class AddingString {

	void printmatrix(String u [][] ,int r,int c) {
		for(int i1=0; i1<r; i1++)

		{
			System.out.println();
			for( int j1=0; j1<c; j1++){	

				System.out.print(" "+u[i1][j1]);
			}
		}
	}

		public static void main(String args[]) 
		{
			int i,j;
			String[][]a ;
			String[][] b; 
			AddingString add=new AddingString();
			Scanner s=new Scanner(System.in);
			System.out.println("Enter the rows of the first matrice : ");
			int r1 = s.nextInt();	
			System.out.println("Enter the columns of the first matrice : ");
			int c1 = s.nextInt();

			System.out.println("Enter the rows of the second matrice : ");
			int r2 = s.nextInt();	
			System.out.println("Enter the columns of the second matrice : ");
			int c2 = s.nextInt();

			

			if(r1==r2&&c1==c2)

			{
				a= new String[r1][c1]; 
				b=new String[r2][c2];
				String[][] sum=new String[r1][c1];
				System.out.println("Enter the elements of the first matrice : ");
				for( i=0; i<r1; i++)
				{

					for( j=0; j<c1; j++){	

						a[i][j] = s.nextLine();
					}
				}

				System.out.println("Enter the elements of the second matrice : ");
				for( i=0; i<r2; i++)
				{
					for( j=0; j<c2; j++){	
						b[i][j] = s.nextLine();
					}
				}	

				// Taking sum

				for( i=0; i<r2; i++)
				{
					
					for( j=0; j<c2; j++){
						sum[i][j]="";
						sum[i][j] =b[i][j].concat(a[i][j]); 
								
								

					}
				}

				

				System.out.println("Added Matrix : " );
				add.printmatrix(sum, r2, c2);
			}//if

			else
			{
				System.out.println("Order of the 2 matrices should be equal " );	
			

			}

			//	System.out.print("First Matrice : " );
			//	ad.printmatrix(a, r1, c1);
			//	System.out.print("Second Matrice : " );
			//	ad.printmatrix(b, r2, c2);



		}

	}
