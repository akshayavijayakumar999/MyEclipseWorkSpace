package july7;

import java.util.Scanner;

public class Implementation {

  public  void reverse(String a[], int n)
	{
		String [] b = new String[n];
		int j = n;
		for (int i = 0; i < n; i++) {
			b[j - 1] = a[i];
			j --;
		}


		System.out.println("Reversed array is: \n");
		for (int k = 0; k < n; k++) {
			System.out.println(b[k]);
		}
	}
  public void search (String ar[],String c) 
  {
	  int i=0;
	  int flag=0;
	  do {
		 if (ar[i].equals(c))
		 
			 {
			 
		 flag=1;
		 
		break;
			 }
		  i++;
		  
	  }
	  
	  while (i<ar.length);
	  
	  if(flag==1)
	  {
		  System.out.println("String   is present at "+(i+1)+"th position ") ;  
	  }
	  else {
	  System.out.println("String  is not present ") ;
	  }
	  
  }

	public static void main(String[] args)
	{
		String [] arr;

		Scanner s=new Scanner(System.in);

		System.out.println("Enter the size of the Array : ");
		int n1 =s.nextInt();

		arr=new String[n1];
		int i=0;

		System.out.println("Enter the elements of the Array : ");
		while(i<n1)
		{
			arr[i]=s.next();
			i++;
			
		}
		Implementation im=new Implementation();
		
		System.out.println("Enter the string to be searched : ");
		String search=s.next();
		
		im.search(arr, search);
		im.reverse(arr, arr.length);
		
		
		
		
		
		
	} 
	
}


