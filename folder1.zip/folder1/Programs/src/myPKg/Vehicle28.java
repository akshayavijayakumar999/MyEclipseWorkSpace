package myPKg;

 class Vehicle28 {}
	
  class Car1 extends Vehicle28 {
		 
		  public static void main(String args[]) {
		 
		     Vehicle28 a = new Car1();
		     boolean result =  a instanceof Car1;
		     System.out.println( result );
		 }

	

	}
