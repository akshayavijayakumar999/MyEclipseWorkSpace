package myPKg;

public class Relational_operators30 {
	public static void main(String as[])
    {
        int a, b;
        a=40;
        b=30;
        System.out.println("a == b = " + (a == b) );
        System.out.println("a != b = " + (a != b) );
        System.out.println("a > b = " + (a > b) );
        System.out.println("a < b = " + (a < b) );
        System.out.println("b >= a = " + (b >= a) );
        System.out.println("b <= a = " + (b <= a) );    
    }


}
