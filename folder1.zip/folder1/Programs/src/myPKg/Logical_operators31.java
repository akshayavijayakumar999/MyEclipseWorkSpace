package myPKg;

public class Logical_operators31 {
	
	public static void main(String as[])
    {
        boolean a = true;
        boolean b = false;
        System.out.println("a && b = " + (a&&b));
        System.out.println("a || b = " + (a||b) );
System.out.println("!(a && b) = " + !(a && b));
    }


}
