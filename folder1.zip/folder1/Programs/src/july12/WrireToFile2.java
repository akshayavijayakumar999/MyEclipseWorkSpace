package july12;

import java.io.Closeable;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class WrireToFile2 {
	
	public static void main(String[] args) {  
		 File f0 = new File("D:word3.doc");
		 
		try {  
	        FileWriter fwrite = new FileWriter(f0); 
	       
	        // writing the content into the FileOperationExample.txt file  
	        fwrite.write("A named location used to store related information is referred to as a File.");   
	   
	        // Closing the stream  
	        fwrite.close();   
	        System.out.println("Content is successfully wrote to the file.");  
	    } catch (IOException e) {  
	        System.out.println("Unexpected error occurred");  
	        e.printStackTrace();  
	       
}
	
}
}
