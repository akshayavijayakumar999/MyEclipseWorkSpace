package july12;

import java.io.File;
import java.io.IOException;

public class DeleteFile1 {
	public static void main(String[] args) {   
	    File f0 = new File("D:FileOperationExample2.txt");   
	    try {
			f0.createNewFile();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    if (f0.delete()) {   
	      System.out.println(f0.getName()+ " file is deleted successfully.");  
	    } else { 
	    	  System.out.println("Unexpected error found in deletion of the file.");  

	    }
	}
}
