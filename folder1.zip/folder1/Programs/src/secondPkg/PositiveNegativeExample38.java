package secondPkg;

public class PositiveNegativeExample38 {
	public static void main(String[] args) {    
	    int number=-13;    
	    if(number>0){  
	    System.out.println("POSITIVE");  
	    }else if(number<0){  
	    System.out.println("NEGATIVE"); 
	    }else{  
	        System.out.println("ZERO");  
	       }  
	    }    


}
