package secondPkg;

public class Fruits50 {

	public static void main(String[] args) {  
	    String name = "Mango";  
	    switch(name){  
	    case "Mango":  
	        System.out.println("It is a fruit");  
	        break;  
	    case "Tomato":  
	        System.out.println("It is a vegitable");  
	        break;  
	    case "Coke":  
	        System.out.println("It is cold drink");  
	    }  
	}  


}
