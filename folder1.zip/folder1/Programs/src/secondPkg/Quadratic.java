package secondPkg;

public class Quadratic {

	public static void main(String args[]){ 
		double a,b,c,d,s1,s2;

		a=15;
		b=5;
		c=3;
		d=(b*b)-(4*a*c);
		if(d==0)
		{
			System.out.println("Only one solution");
			s1=(-b + Math.sqrt(d))/(2*a);
			System.out.println("Root is :: "+ s1);
		
		}

		else if (d>0)
		{

			System.out.println("Two solutions");

			s1=(-b + Math.sqrt(d))/(2*a);
			s2=(-b - Math.sqrt(d))/(2*a);

			System.out.println("First Root is :: "+ s1);
			System.out.println("Second Root is :: "+ s2);
		}
		else
		{
			s1=(-b)/(2*a);
			s2=Math.sqrt(-d)/(2*a);
			
			System.out.println("Two imaginary solutions");
			System.out.println("First Root is :: "+ s1 + "+i"+s2);
			System.out.println("Second Root is :: "+ s1 + "-i"+s2);
		}

	}
}
