package thirdPkg;

import java.util.Scanner;

public class AdditionMatrix28 {

	void printmatrix(int u [][] ,int r,int c) {
		for(int i1=0; i1<r; i1++)

		{
			System.out.println();
			for( int j1=0; j1<c; j1++){	

				System.out.print(" "+u[i1][j1]);
			}
		}

	}

	public static void main (String args[]){
		int i,j;
		int[][]a ;
		int[][] b; 
		AdditionMatrix28 ad=new AdditionMatrix28();
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the rows of the first matrice : ");
		int r1 = s.nextInt();	
		System.out.println("Enter the columns of the first matrice : ");
		int c1 = s.nextInt();

		System.out.println("Enter the rows of the second matrice : ");
		int r2 = s.nextInt();	
		System.out.println("Enter the columns of the second matrice : ");
		int c2 = s.nextInt();

		a= new int[r1][c1]; 
		b=new int[r2][c2];
		int[][] sum=new int[r1][c1];

		if(r1==r2&&c1==c2)

		{
			System.out.println("Enter the elements of the first matrice : ");
			for( i=0; i<r1; i++)
			{

				for( j=0; j<c1; j++){	

					a[i][j] = s.nextInt();
				}
			}

			System.out.println("Enter the elements of the second matrice : ");
			for( i=0; i<r2; i++)
			{
				for( j=0; j<c2; j++){	
					b[i][j] = s.nextInt();
				}
			}	

			// Taking sum

			for( i=0; i<r2; i++)
			{
				for( j=0; j<c2; j++){	
					sum [i][j] =a[i][j] + b[i][j];

				}
			}

			for( i=0; i<r2; i++)
			{
				for( j=0; j<c2; j++){	
					sum [i][j] =a[i][j] + b[i][j];

				}
			}


			System.out.println("Sum : " );
			ad.printmatrix(sum, r2, c2);
		}//if
		
		else
		{
			System.out.println("Order of the 2 matrices should be equal " );	
		}

//		System.out.print("First Matrice : " );
//		ad.printmatrix(a, r1, c1);
//		System.out.print("Second Matrice : " );
//		ad.printmatrix(b, r2, c2);
		
		

	}
}



