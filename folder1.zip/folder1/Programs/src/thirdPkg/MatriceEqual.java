package thirdPkg;
//  Java Program to determine whether two matrices are equal

import java.util.Scanner;

public class MatriceEqual {
	public static void main(String[] args) {

		int i,j;
		int[][]a ;
		int[][]b; 
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the rows of the first matrice : ");
		int r1 = s.nextInt();	
		System.out.println("Enter the columns of the first matrice : ");
		int c1 = s.nextInt();

		System.out.println("Enter the rows of the second matrice : ");
		int r2 = s.nextInt();	
		System.out.println("Enter the columns of the second matrice : ");
		int c2 = s.nextInt();


		if(r1==r2&&c1==c2)

		{
			a= new int[r1][c1]; 
			b=new int[r2][c2];

			System.out.println("Enter the elements of the first matrice : ");
			for( i=0; i<r1; i++)
			{

				for( j=0; j<c1; j++){	

					a[i][j] = s.nextInt();
				}
			}

			System.out.println("Enter the elements of the second matrice : ");
			for( i=0; i<r2; i++)
			{
				for( j=0; j<c2; j++){	
					b[i][j] = s.nextInt();
				}
			}

			int flag=0;

			for(i=0;i<r1;i++){    
				for(j=0;j<c1;j++){    
					if((a[i][j])!=(b[i][j]))
					{
						flag=1;
						break;   
					}
				}  
			}

			if(flag==0)
				System.out.println("Matrices are equal...");
			else
				System.out.println("Matrices are not equal...");

		}
		else
			System.out.println("Order of the two Matrices should be equal...");

	}
}
