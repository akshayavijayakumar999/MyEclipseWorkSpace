package thirdPkg;

import java.util.Scanner;

public class DistancebwPoints8 {

	public static void main(String arg[])	
	{
		double x1,x2,y1,y2;
		double dis;
		Scanner s = new Scanner(System.in);
		System.out.println("Enter the X coordinate of first point : ");
		x1 = s.nextDouble();

		System.out.println("Enter the Y coordinate of first point: ");
		y1 = s.nextDouble();

		System.out.println("Enter the X coordinate of second point: ");
		x2 = s.nextDouble();

		System.out.println("Enter the Y coordinate of second point: ");
		y2 = s.nextDouble();

		dis=Math.sqrt((x2-x1)*(x2-x1) + (y2-y1)*(y2-y1));	 	    
		System.out.println("distancebetween"+"("+x1+","+y1+") and "+"("+x2+","+y2+")= "+dis);
		s.close();
	}

}
