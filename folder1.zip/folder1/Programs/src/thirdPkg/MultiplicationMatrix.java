package thirdPkg;

import java.util.Scanner;

public class MultiplicationMatrix {

	public static void main(String[] args) {

		int i,j;
		int[][]a ;
		int[][]b; 
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the rows of the first matrice : ");
		int r1 = s.nextInt();	
		System.out.println("Enter the columns of the first matrice : ");
		int c1 = s.nextInt();

		System.out.println("Enter the rows of the second matrice : ");
		int r2 = s.nextInt();	
		System.out.println("Enter the columns of the second matrice : ");
		int c2 = s.nextInt();


		if(c1==r2)

		{
			a= new int[r1][c1]; 
			b=new int[r2][c2];
			int[][] sum=new int[r1][c2];
			System.out.println("Enter the elements of the first matrice : ");
			for( i=0; i<r1; i++)
			{

				for( j=0; j<c1; j++){	

					a[i][j] = s.nextInt();
				}
			}

			System.out.println("Enter the elements of the second matrice : ");
			for( i=0; i<r2; i++)
			{
				for( j=0; j<c2; j++){	
					b[i][j] = s.nextInt();
				}
			}

			for(i=0;i<r1;i++){    
				for(j=0;j<c2;j++){    
					sum[i][j]=0;      
					for(int k=0;k<r2;k++)       
					{      
						sum[i][j]+=a[i][k]*b[k][j];      
					}//end of k loop  
					System.out.print(sum[i][j]+" ");  //printing matrix element  
				}//end of j loop  
				System.out.println();//new line   

			}

		}
		
		else {
			System.out.println("Order of the 2 matrices should be equal " );	
		}
		s.close();
	}
}
