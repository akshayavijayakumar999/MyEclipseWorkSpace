package thirdPkg;

public class Weight {
	
	public static void main(String args[]){ 

		String name="Arun";
		char gender='F';
		double height=180;
		double weight=180;

		
		
		

		double bmi = (100*100*weight) / ( height * height) ;

		

		System.out.println("------------------------------------- ");
		System.out.println("Hai "+name);
		System.out.println("Height : "+height+" cm");
		System.out.println("Weight : "+weight+" kg");
		System.out.println("Gender: "+gender);

		switch(gender)
		{
		case 'M': // For male

			if (bmi < 18.5) {
				System.out.println("......You are UNDERWEIGHT....");
			} else if ((bmi >=18.5) & (bmi<= 25)) {
				System.out.println("......You are NORMALWEIGHT....");
			} else if ((bmi >=25) 
					& (bmi<= 30)) {
				System.out.println("......You are OVERWEIGHT......");
			} else {
				System.out.print("........You are OBESE............");
			}		

			break;
		case 'F': // For female
			if (bmi < 18.5) {
				System.out.println("......You are UNDERWEIGHT....");
			} else if ((bmi >=18.5) & (bmi<= 25)) {
				System.out.println("......You are NORMALWEIGHT....");
			} else if ((bmi >=25) & (bmi<= 30)) {
				System.out.println("......You are OVERWEIGHT......");
			} else {
				System.out.print("........You are OBESE............");
			}
			break;
		}
		System.out.println("------------------------------------- ");
		

	}

}
