package thirdPkg;

import java.util.Scanner;

public class Text5 {
	public static void main(String[] args) {

		Scanner s = new Scanner(System.in);
		System.out.print("Enter the text: ");
		String n= s.nextLine(); 

		for(int j=0;j<5;j++){

			System.out.print(n);
			System.out.println();
		}
		s.close();
	}
}
