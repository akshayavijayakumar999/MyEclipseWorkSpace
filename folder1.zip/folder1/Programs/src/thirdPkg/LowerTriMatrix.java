package thirdPkg;

import java.util.Scanner;

public class LowerTriMatrix {
	
	public static void main(String[] args) {    
	    int i,j;
		Scanner s=new Scanner(System.in);
	    System.out.println("Enter the rows of the  matrice : ");
		int r1 = s.nextInt();	
		System.out.println("Enter the columns of the  matrice : ");
		int c1 = s.nextInt();
		
	            
	            
	          if(r1 != c1){    
	              System.out.println("Matrix should be a square matrix");    
	          }    
	          else {  
	        	  int[][]a= new int[r1][c1];
	        	  System.out.println("Enter the elements of the first matrice : ");
	  			for( i=0; i<r1; i++)
	  			{

	  				for( j=0; j<c1; j++){	

	  					a[i][j] = s.nextInt();
	  				}
	  			}
	        	  
	        	  
	              //Performs required operation to convert given matrix into lower triangular matrix    
	              System.out.println("Lower triangular matrix: ");    
	              for( i = 0; i < r1; i++){    
	                  for( j = 0; j < c1; j++){    
	                    if(j > i)    
	                      System.out.print("0 ");    
	                    else    
	                      System.out.print(a[i][j] + " ");    
	                }    
	                System.out.println();    
	            }    
	        }    
	    }    

}
