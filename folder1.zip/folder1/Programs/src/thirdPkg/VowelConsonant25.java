package thirdPkg;

import java.util.Scanner;

public class VowelConsonant25 {
	public static void main (String args[]){

		Scanner s = new Scanner(System.in);
		System.out.println("Enter the  character: ");
		char c=s.next().charAt(0);
		switch (c) {
		case 'a':
		case 'e':
		case 'i':
		case 'o':
		case 'u':
		case  'A' :
		case 'E'  :
		case 'I'   :
		case 'U'  :
			System.out.println(c + " is vowel");
			break;
		default:
			System.out.println(c + " is consonant");

		}
		s.close();
	}
}
