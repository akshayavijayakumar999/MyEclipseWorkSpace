package thirdPkg;

import java.util.Scanner;

public class SubtractionMatrix29 {

	void printmatrix(int u [][] ,int r,int c) {
		for(int i1=0; i1<r; i1++)

		{
			System.out.println();
			for( int j1=0; j1<c; j1++){	

				System.out.print(" "+u[i1][j1]);
			}
		}
	}

		public static void main(String args[]) 
		{
			int i,j;
			int[][]a ;
			int[][] b; 
			SubtractionMatrix29 sub=new SubtractionMatrix29();
			Scanner s=new Scanner(System.in);
			System.out.println("Enter the rows of the first matrice : ");
			int r1 = s.nextInt();	
			System.out.println("Enter the columns of the first matrice : ");
			int c1 = s.nextInt();

			System.out.println("Enter the rows of the second matrice : ");
			int r2 = s.nextInt();	
			System.out.println("Enter the columns of the second matrice : ");
			int c2 = s.nextInt();

			

			if(r1==r2&&c1==c2)

			{
				a= new int[r1][c1]; 
				b=new int[r2][c2];
				int[][] dif=new int[r1][c1];
				System.out.println("Enter the elements of the first matrice : ");
				for( i=0; i<r1; i++)
				{

					for( j=0; j<c1; j++){	

						a[i][j] = s.nextInt();
					}
				}

				System.out.println("Enter the elements of the second matrice : ");
				for( i=0; i<r2; i++)
				{
					for( j=0; j<c2; j++){	
						b[i][j] = s.nextInt();
					}
				}	

				// Taking sum

				for( i=0; i<r2; i++)
				{
					for( j=0; j<c2; j++){	
						dif[i][j] =a[i][j] + b[i][j];

					}
				}

				for( i=0; i<r2; i++)
				{
					for( j=0; j<c2; j++){	
						dif [i][j] =a[i][j] - b[i][j];

					}
				}


				System.out.println("Difference : " );
				sub.printmatrix(dif, r2, c2);
			}//if

			else
			{


			}

			//	System.out.print("First Matrice : " );
			//	ad.printmatrix(a, r1, c1);
			//	System.out.print("Second Matrice : " );
			//	ad.printmatrix(b, r2, c2);



		}

	}
