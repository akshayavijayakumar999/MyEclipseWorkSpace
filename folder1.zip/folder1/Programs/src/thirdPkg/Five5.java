package thirdPkg;

import java.util.Scanner;

public class Five5 {
	
	public static void main(String[] args)
	{
	
	
	Scanner sc=new Scanner(System.in);
	System.out.print("Enter the rows: ");
	int rows=sc.nextInt(); //get input from user
	
	System.out.print("Enter the rows: ");
	int col=sc.nextInt(); //get input from user
	
	for(int i=1; i<=rows; i++){//Print each row 
	for(int j=1; j<=col; j++){//Print space for Pyramid shape 
	System.out.println(" * "); 
	} 

}
	sc.close();
	}
}
