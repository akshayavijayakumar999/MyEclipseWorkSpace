package thirdPkg;

import java.util.Scanner;

public class StringReverse20 {
	public static void main (String args[]){	
	String s, reverse = "";
    Scanner scan = new Scanner(System.in);

    System.out.println("Enter a string to reverse: ");
    s = scan.nextLine();

    int length = s.length();

    for (int i = length - 1 ; i >= 0 ; i--)
      reverse = reverse + s.charAt(i);

    System.out.println("Reverse of the string: " + reverse);
    scan.close();

}
}
