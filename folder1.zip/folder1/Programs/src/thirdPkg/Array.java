package thirdPkg;

public class Array {

	public static void main(String args[]) 
	{
	int[]a= {1,2,3,4} ;
	int i=0;
	while(i<a.length)
	{
		System.out.println(a[i]);
		i++;
		}
	}	
}

