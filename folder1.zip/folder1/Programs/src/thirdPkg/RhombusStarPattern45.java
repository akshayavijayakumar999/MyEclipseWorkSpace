package thirdPkg;

import java.util.Scanner;
public class RhombusStarPattern45
{
	public  void printStars(int n)
	{

		for(int i=1;i<=n;i++)
		{
			for(int j=1;j<=n-i;j++)

			{
				System.out.print(" ");
			}
			for(int j=1;j<=n;j++)

			{	


				System.out.print("*");
			}

			System.out.println();

		}             

	}

	public static void main(String[] args)
	{

		Scanner s=new Scanner(System.in);
		System.out.println("Enter N : ");
		int n=s.nextInt();
		RhombusStarPattern45 r= new RhombusStarPattern45();
		r.printStars(n);
		
		s.close();



	}
}
