package thirdPkg;

import java.util.Scanner;

public class TransposeMatrix30 {
	
	void printmatrix(int u [][] ,int r,int c) {
		for(int i1=0; i1<r; i1++)

		{
			System.out.println();
			for( int j1=0; j1<c; j1++){	

				System.out.print(" "+u[i1][j1]);
			}
		}
	}
	public static void main(String args[]) 
	{
	int i,j;
	int[][]a ;
	int[][]t; 
	TransposeMatrix30 tr=new TransposeMatrix30();
	Scanner s=new Scanner(System.in);
	System.out.println("Enter the rows of the first matrice : ");
	int r = s.nextInt();	
	System.out.println("Enter the columns of the first matrice : ");
	int c= s.nextInt();
	a= new int[r][c]; 
	t= new int[c][r];
	System.out.println("Enter the elements of the matrice : ");
	for( i=0; i<r; i++)
	{

		for( j=0; j<c; j++){	

			a[i][j] = s.nextInt();
		}
	}
	
	for( i=0; i<r; i++)
	{

		for( j=0; j<c; j++){	

			t[j][i] =a[i][j] ;
			
		}
	}

	System.out.println("Transpose : " );
	tr.printmatrix(t, c, r);
}
}