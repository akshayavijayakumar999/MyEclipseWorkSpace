package thirdPkg;

import java.util.Scanner;

public class SquareStarPattern43 {
	

	public static void main(String[] args)
	{
	int side, i, j;
	Scanner s = new Scanner(System.in);
	
	System.out.print("  Enter the Side of  Square : ");
	side = s.nextInt();	
		
	for(i = 1; i <= side; i++)
	{
		for(j = 1; j <= side; j++)
		{
			System.out.print("*"); 
		}
		System.out.print("\n"); 
	}	
}
}


