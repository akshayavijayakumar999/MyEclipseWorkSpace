package thirdPkg;

import java.util.Scanner;

public class ElectricityBill {

	public void  calculateBill(long u) {	   

		double pay=0;

		if(u<100)
			pay=u*1.20;

		else if(u<300)
			pay=100*1.20+(u-100)*2;

		else if(u>300)
			pay=100*1.20+200 *2+(u-300)*3;

		System.out.println("Bill to pay : Rs " + pay +" only"); 
	} 

	public static void main(String args[]) 
	{
		long units;

		Scanner s=new Scanner(System.in);

		System.out.println("Enter number of units used:");
		units=s.nextLong();
		ElectricityBill e =new ElectricityBill ();
		e.calculateBill(units);
		s.close();
	}
}