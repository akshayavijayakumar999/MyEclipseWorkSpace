package thirdPkg;

import java.util.Scanner;

public class CheckWeight {

	public static void main(String args[]){ 

		String n;
		char g;
		double h,w,a;
		Scanner s = new Scanner(System.in);
		// Input the sides
		System.out.println("Enter Your Name: ");
		n= s.nextLine(); 
		System.out.println("Enter Your Height (in cm ): ");
		h = s.nextDouble();

		System.out.println("Enter Your weight  (in Kg): ");
		w = s.nextDouble();

		double bmi = (100*100*w) / ( h * h) ;
		
		System.out.println("Enter Your Age: "); 
		a=s.nextDouble();
		
		System.out.println("Enter Your Gender (M/F): ");
		g = s.next().charAt(0); 

		g=Character.toUpperCase(g);

		System.out.println("------------------------------------- ");
		System.out.println("Hai "+n);
		System.out.println("Height : "+h+" cm");
		System.out.println("Weight : "+w+" kg");
		System.out.println("Gender: "+g);
		System.out.println("Age: "+a);
		switch(g)
		{
		case 'M': // For male

			
			if (bmi < 18.5) {
				System.out.println("......You are UNDERWEIGHT....");
			} else if ((bmi >=18.5) & (bmi<= 25)) {
				System.out.println("......You are NORMALWEIGHT....");
			} else if ((bmi >=25) 
					& (bmi<= 30)) {
				System.out.println("......You are OVERWEIGHT......");
			} else {
				System.out.print("........You are OBESE............");
			}		

			break;
		case 'F': // For female
			if (bmi < 18.5) {
				System.out.println("......You are UNDERWEIGHT....");
			} else if ((bmi >=18.5) & (bmi<= 25)) {
				System.out.println("......You are NORMALWEIGHT....");
			} else if ((bmi >=25) & (bmi<= 30)) {
				System.out.println("......You are OVERWEIGHT......");
			} else {
				System.out.print("........You are OBESE............");
			}
			break;
		}
		System.out.println("------------------------------------- ");
		s.close();

	}

}
