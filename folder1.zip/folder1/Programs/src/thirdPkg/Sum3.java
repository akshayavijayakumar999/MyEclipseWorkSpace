package thirdPkg;

import java.util.Scanner;

public class Sum3 {
	public static void main(String[] args) {	
	int sum=0;
	int i;
	Scanner s = new Scanner(System.in);
	System.out.println("Enter the Limit: ");
	
	int n= s.nextInt();
	for(i=1;i<=n;i++){    
		sum=sum+i;    
	} 
	System.out.println("Sum : " +sum);
	s.close();
	}
}
