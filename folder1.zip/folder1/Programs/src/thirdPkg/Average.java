package thirdPkg;

import java.util.Scanner;

public class Average {
	public static void main(String args[]) 
	{	
	
		int i;
		int[] numbers;

		float average, sum = 0;  
		Scanner s = new Scanner(System.in);
		System.out.println("Enter the Limit : ");
		int n= s.nextInt();
		numbers= new int[n];  
		
		System.out.println("Enter the Numbers : ");
		
		for(i=0;i<n;i++){    
			numbers[i]= s.nextInt();

			sum=sum+numbers[i];
		} 

		average=sum/n;
		System.out.println("Average: " +average);

	}
}
