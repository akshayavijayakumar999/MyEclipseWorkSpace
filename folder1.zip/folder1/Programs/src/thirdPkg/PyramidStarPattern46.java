package thirdPkg;

import java.util.Scanner;

public class PyramidStarPattern46 {
	
	public  void printStars(int n)
    {
      
		// outer loop to handle number of rows
        //  n in this case
        for (int i=0; i<n; i++)
        {
 
            // inner loop to handle number spaces
            // values changing acc. to requirement
            for (int j=n-i; j>1; j--)
            {
                // printing spaces
                System.out.print(" ");
            }
  
            //  inner loop to handle number of columns
            //  values changing acc. to outer loop
            for (int j=0; j<=i; j++ )
            {
                // printing stars
                System.out.print("* ");
            }
  
            // ending line after each row
            System.out.println();
        }
    }
     
 
     // Main Function
        public static void main(String args[])
        {
        	Scanner s = new Scanner(System.in);
        	System.out.println("Enter the Limit : ");
    		int n= s.nextInt();
    		PyramidStarPattern46 p=new PyramidStarPattern46();
    		
            p.printStars(n);
            s.close();
        }
    

}
