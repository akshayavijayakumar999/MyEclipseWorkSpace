package thirdPkg;

import java.util.Scanner;

public class HollowRhombusPattern60 {
	public static void main(String[] args)
	{
		Scanner scan=new Scanner(System.in); 
		  //create a scanner object for input
		  
		System.out.println("Enter the number of rows: ");
		//Ask input from the user
		int rows=scan.nextInt();
		
		for(int i=1; i<=rows; i++){//outer for loop 
			   for(int j=1; j<=rows-i; j++){//inner for loop 
			   System.out.print(" ");//print space
			   }
			   for(int j=1; j<=rows; j++){//inner for loop
			   if(i==1 || i==rows || j==1 || j==rows){
			   System.out.print("*");//print symbol after space
			   }
			   else{
			       System.out.print(" ");//print space
			   }
			}
			 System.out.print("\n");//move to next line
			}
		scan.close();
			}
}
	
