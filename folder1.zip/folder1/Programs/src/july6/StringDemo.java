package july6;


public class StringDemo {

	public static void main(String args[]) {
		// String palindrome = "j a v a tutorial";
		String palindrome = "Dot saw I was Tod";

		int len = palindrome.length();
		System.out.println( "String Length is : " + len );
	}


}

