package july6;

public class Concat {
	
	 
	   public static void main(String args[]) {
	      String string1 = "saw I was ";
	      System.out.println("Dot " + string1 + "Tod");
	   }


}
