package july6;

import java.util.Scanner;

public class StringDivide {
	public static void main(String args[]) {
		
		Scanner s = new Scanner(System.in);
		System.out.println("Enter the string:");
		String str=s.nextLine();
		  
        //Stores the length of the string  
         
        
        System.out.println("How many parts the string should be divided");
        
        //n determines the variable that divide the string in 'n' equal parts  
        
        int n = s.nextInt(); 
        int len = str.length();
        System.out.println("Length of the String: " +len);
        
        int temp = 0, chars = len/n;  
        //Stores the array of string  
        String[] divide = new String [n];  
        //Check whether a string can be divided into n equal parts  
        if(len % n != 0) {  
            System.out.println("Sorry this string cannot be divided into "+ n +" equal parts.");  
        }  
        else {  
            for(int i = 0; i < len; i = i+chars) {  
                //Dividing string in n equal part using substring()  
                String part = str.substring(i, i+chars);  
                divide[temp] = part;  
                temp++;  
            }  
    System.out.println(n + " equal parts of given string are ");  
            for(int i = 0; i < divide.length; i++) {  
                System.out.println(divide[i]);  
                }  
            }  
	}
}
