package july6;

public class Format {
	  public static void main(String args[]) {
		  float floatvar=3.0F;
		  int intVar=7;
		  String stringVar="hai";
	System.out.printf("The value of the float variable is " +
            "%f, while the value of the integer " +
            "variable is %d, and the string " +
            "is %s", floatvar, intVar, stringVar);
	
	String fs;
	fs = String.format("The value of the float variable is " +
	                   "%f, while the value of the integer " +
	                   "variable is %d, and the string " +
	                   "is %s", floatvar, intVar, stringVar);
	System.out.println(fs);


	  }

}
