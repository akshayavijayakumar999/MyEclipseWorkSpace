package july6;

public class StringReverse {
	public static void main(String args[]) {
		String s="hello world";
		StringBuilder sb=new StringBuilder(s); 
		sb.reverse();
		
	System.out.println("String Reverse: "+ sb);
	
	
	int[][] myNumbers = { {1, 2, 3, 4}, {5, 6, 7} };
	int x = myNumbers[1][2];
	System.out.println(x); 

}
}
