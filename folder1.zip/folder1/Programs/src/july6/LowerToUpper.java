package july6;

public class LowerToUpper {

	public static void main(String args[]) {
		String s="HELLOWORLD";

		String s1lower=s.toLowerCase();  
		System.out.println(s1lower);  


		String s2="hello world";

		String upper=s2.toUpperCase();  
		System.out.println(upper);  


	}

}
