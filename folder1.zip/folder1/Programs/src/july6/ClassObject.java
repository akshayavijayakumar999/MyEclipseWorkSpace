package july6;

public class ClassObject {

	int x=10;
	int y=10;
	int a;

	public void add()
	{
		a=x+y;
		System.out.println("a:" +a);
	}

	public void sub(int x,int y)
	{
		int b=x-y;
		System.out.println("b:" +b);
	}

	public void sub(int x,int y,int u)
	{
		int c=x-y-u;
		System.out.println("c:" +c);
	}
	
	
	public double sub(double x,double y,double u)
	{
		return (x-y-u);
	}



	public static void main(String args[]) 
	{
		ClassObject c= new  ClassObject();
		System.out.println(c.x);
		System.out.println(c.y);

		c.add();
		int s1=3;
		int s2=1;
		int s3=1;
		c.sub(s1,s2);
		c.sub(s1, s2,s3);
		double e1=40;
		double e2=6;
		double e3=7;
		double e=c.sub(e1, e2,e3);
		System.out.println("e:" +e);



	}

}
