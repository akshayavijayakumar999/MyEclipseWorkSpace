package july6;

class Class1 {
	int a=10;
	String name="Training";
	
	public void print()
	{

	String place ="Kerala";
	System.out.println("Place Name : " +place);
	}

}

public class Class2 {
	public static void main(String args[]) { 
		Class1 c= new Class1();
		System.out.println("Value of a :"+c.a);
		System.out.println("Value of name :"+c.name);
		c.print();
		
	}
	
}	


