package july5;

public class WhileExample60 {
	public static void main(String[] args) {  
	    while(true){  
	        System.out.println("infinitive while loop");  
	    }  
	}  

}
