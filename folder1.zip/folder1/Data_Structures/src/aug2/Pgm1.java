package aug2;

import java.util.Scanner;

public class Pgm1 {
	
	public static void main(String[] args) {  
	    int[] arr; 
	    
	    int item,flag=0;
	    
	    
	    Scanner sc=new Scanner(System.in);  
		System.out.print("Enter the limit of the array: ");  
		int n = sc.nextInt();
		arr= new int[n];  
		System.out.print("Enter the Elements of the array: ");
		for(int i=0;i<n;i++)
		{

			arr[i]=sc.nextInt();
		}
	    
	     
	    for(int i=0;i<n;i++)  
	    {  
	        for (int j=0;j<n;j++)  
	        {  
	            if(arr[i]<arr[j])  
	            {  
	                int temp = arr[i];  
	                arr[i]=arr[j];  
	                arr[j] = temp;   
	                
	            }  
	        }  
	    }  
	    System.out.println("Printing Sorted List ...");  
	    for(int i=0;i<n;i++)  
	    {  
	        System.out.println(arr[i]);  
	    }  
	
	
	     
	    System.out.println("Enter Item ?");  
	    item = sc.nextInt();  
	    for(int i = 0; i<n; i++)  
	    	
	    {  
	        if(arr[i]==item)  
	        {  
	            flag = i+1;  
	            break;  
	        }  
	        else   
	            flag = 0;   
	    }  
	    if(flag != 0)  
	    {  
	        System.out.println("Item found at location " + flag);  
	    }  
	    else   
	        System.out.println("Item not found");  
	      
	}  

}
