package Programs;

import java.util.Scanner;

// 12.Area Of Rhombus

public class RhombusArea12 {

	public void area(double d1,double d2) // Function to find the area
	{
		double area;
		area= ((d1*d2)/2);
		System.out.println();
		System.out.println("Area of Rhombus : "+ area);
	}


	public static void main(String[] args) {
		
		double diagonal1,diagonal2;

		// Input the length
		System.out.println("Enter the length of First Diagonal: ");

		// Create Scanner object
		Scanner s = new Scanner(System.in);

		// Read the next Double from the screen
		diagonal1 = s.nextDouble();

		System.out.println("Enter the length of Second Diagonal: ");
		diagonal2 = s.nextDouble();

		RhombusArea12	r= new RhombusArea12();
		r.area(diagonal1,diagonal2);
		s.close();

	}

}
