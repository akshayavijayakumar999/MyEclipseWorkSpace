package Programs;
// 15. Perimeter Of Equilateral Triangle

import java.util.Scanner;

public class EquilateralTrianglePerimeter15 {
	
	private void perimeter(double s) {
		double perimeter;
		perimeter= (3*s);
		System.out.println();
		System.out.println("Perimeter of Equilateral Triangle : "+ perimeter);
		
	}
	public static void main(String[] args) {

		double side;

		System.out.println("Enter the side: ");

		// Create Scanner object
		Scanner s = new Scanner(System.in);

		side = s.nextDouble();

		EquilateralTrianglePerimeter15	e= new EquilateralTrianglePerimeter15();
		e.perimeter(side);
		s.close();

	}

	
}
