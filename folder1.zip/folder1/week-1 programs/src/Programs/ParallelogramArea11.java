package Programs;

import java.util.Scanner;

// 11. Area Of Parallelogram
public class ParallelogramArea11 {
	
	public void area(double b,double h) // Function to find the area
	{
		double area;
		area= b*h;
		System.out.println();
		System.out.println("Area of Parallelogram : "+ area);
	}
	
	public static void main(String[] args) {
		double base,height;

		// Input the base
		System.out.println("Enter the base: ");
		
		// Create Scanner object
		Scanner s = new Scanner(System.in);

		// Read the next Double from the screen
		base = s.nextDouble();

		System.out.println("Enter the height: ");
		height = s.nextDouble();

		ParallelogramArea11	p= new ParallelogramArea11();
		p.area(base,height);
		s.close();

	}

}
