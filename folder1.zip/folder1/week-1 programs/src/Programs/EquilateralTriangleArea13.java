package Programs;

import java.util.Scanner;

// 13.Area Of Equilateral Triangle

public class EquilateralTriangleArea13 {

	public void area(double a) // Function to find the area
	{
		double area;
		area= (Math.sqrt(3)/4)*a*a;
		System.out.println();
		System.out.println("Area of Equilateral Triangle : "+ area);
	}

	public static void main(String[] args) {

		double side;

		System.out.println("Enter the side: ");

		// Create Scanner object
		Scanner s = new Scanner(System.in);

		// Read the next Double from the screen
		side = s.nextDouble();



		EquilateralTriangleArea13	e= new EquilateralTriangleArea13();
		e.area(side);
		s.close();

	}
}