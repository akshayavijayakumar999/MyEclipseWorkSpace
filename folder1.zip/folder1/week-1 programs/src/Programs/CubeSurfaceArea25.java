package Programs;

import java.util.Scanner;

// 25.Curved Surface Area Of Cube
public class CubeSurfaceArea25 {
	public void surfaceArea(double s) // Function to find the Surface Area
	{
		double area;
		area= (6*s*s);
		System.out.println();
		System.out.println("Curved Surface Area Of Cube : "+ area);
	}

	public static void main(String[] args) {

		double side;

		System.out.println("Enter the side: ");

		// Create Scanner object
		Scanner s = new Scanner(System.in);

		side = s.nextDouble();

		CubeSurfaceArea25	c= new CubeSurfaceArea25();
		c.surfaceArea(side);

		s.close();
	}

}
