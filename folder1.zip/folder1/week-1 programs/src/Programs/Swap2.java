package Programs;

// 2. Swap two numbers using temporary variable

public class Swap2 {


	public static void main(String[] args) {

		float first = 2.30f, second = 8.95f;

		System.out.println("Before swap");
		System.out.println("First number : " + first);
		System.out.println("Second number : " + second);

		float temporary = first; // Temporary variable
		first = second; // Swapping the two numbers using temporary variable
		second = temporary;

		System.out.println();

		System.out.println("After swap");
		System.out.println("First number : " + first);
		System.out.println("Second number : " + second);
	}
}

