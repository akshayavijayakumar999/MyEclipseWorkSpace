package Programs;

import java.util.Scanner;

public class NumberReverse30 {
	// Program to reverse a number 
	public static void main(String[] args)
    {
		int n;
		int l,r=0;
		Scanner s = new Scanner(System.in);
        System.out.println("Enter the number : ");
        n = s.nextInt();
        
        while(n>0)
        {
        l=n % 10;
        r=((r*10)+l);
        n=n/10;
        }
        System.out.println("Reversed Number: "+r);
        
        s.close();

    }

}
