package Programs;

import java.util.Scanner;

public class QuotientRemainder1 {
	
	public static void main(String[] args) {

	    double dividend,divisor;
	    
	 // Create Scanner object
 		Scanner s = new Scanner(System.in);
	
	 		System.out.println("Enter the Dividend: ");
	 		dividend = s.nextDouble();
	 		System.out.println("Enter the Divisor: ");
	 		divisor = s.nextDouble();

	 		
	    double quotient = dividend / divisor;
	    double remainder = dividend % divisor;

	    System.out.println("Quotient = " + quotient);
	    System.out.println("Remainder = " + remainder);
	    s.close();
	  }

}
