package Programs;

import java.util.Scanner;

// 23.Volume Of Sphere

public class SphereVolume23 {
	
	public void volume(double r) // Function to find the Volume
	{
		double vol;
		vol= (4*3.14*r*r*r)/3;
		System.out.println();
		System.out.println("Volume Of Sphere : "+ vol);
	}
	
	public static void main(String[] args) {
		double radius;

		// Create Scanner object
		Scanner s = new Scanner(System.in);

		System.out.println("Enter the radius of the Sphere: ");
		radius = s.nextDouble();

		SphereVolume23	s1= new SphereVolume23();
		s1.volume(radius);
		s.close();

	}

}
