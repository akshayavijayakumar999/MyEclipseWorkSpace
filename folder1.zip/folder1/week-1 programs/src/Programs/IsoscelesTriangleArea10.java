package Programs;

import java.util.Scanner;

// 10. Area Of Isosceles Triangle

public class IsoscelesTriangleArea10 {

	public void area(double h,double b) // Function to find the area
	{
		double area;
		area= .5*b*h;
		System.out.println();
		System.out.println("Area of Isosceles Triangle : "+ area);
	}

	public static void main(String[] args) {

		double height,base;

		System.out.println("Enter the height: ");

		// Create Scanner object
		Scanner s = new Scanner(System.in);

		
		height = s.nextDouble();

		System.out.println("Enter the base: ");


		// Read the next Double from the screen
		base = s.nextDouble();


		IsoscelesTriangleArea10	i= new IsoscelesTriangleArea10();
		i.area(height,base);
		s.close();

	}	

}
