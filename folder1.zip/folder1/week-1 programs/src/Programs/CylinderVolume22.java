package Programs;

import java.util.Scanner;
//22. Volume Of Cylinder
public class CylinderVolume22 {

	public void volume(double r,double h) // Function to find the Volume
	{
		double vol;
		vol= (3.14*r*r*h);
		System.out.println();
		System.out.println("Volume Of Cylinder : "+ vol);
	}

	public static void main(String[] args) {
		double radius,height;

		// Create Scanner object
		Scanner s = new Scanner(System.in);

		System.out.println("Enter the base radius of the Cylinder: ");
		radius = s.nextDouble();

		System.out.println("Enter the height of the Cylinder: ");
		height = s.nextDouble();

		CylinderVolume22 c= new CylinderVolume22();
		c.volume(radius,height);

		s.close();

	}

}
