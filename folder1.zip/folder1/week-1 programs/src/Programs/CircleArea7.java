package Programs;

import java.util.Scanner;

//7. Area Of Circle Java Program

public class CircleArea7 {

	public void area(double r) // Function to find the area
	{
		double area;
		area= 3.14 *r*r;
		System.out.println();
		System.out.println("Area of Circle : "+ area);

	}

	public static void main(String[] args) {
		double radius;

		// Input the radius
		System.out.println("Enter the radius: ");

		// Create Scanner object
		Scanner s = new Scanner(System.in);

		// Read the next Double from the screen
		radius = s.nextDouble();

		CircleArea7	c= new CircleArea7();
		c.area(radius);

		s.close();
	}
}