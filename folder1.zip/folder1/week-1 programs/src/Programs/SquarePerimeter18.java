package Programs;

import java.util.Scanner;

// 18.Perimeter Of Square

public class SquarePerimeter18 {
	
	private void perimeter(double s) {
		double per;
		per= (4*s);
		System.out.println();
		System.out.println("Perimeter of Equilateral Triangle : "+ per);
		
	}
	
	public static void main(String[] args) {

		double side;

		System.out.println("Enter the side: ");

		// Create Scanner object
		Scanner s = new Scanner(System.in);

		side = s.nextDouble();

		SquarePerimeter18	e= new SquarePerimeter18();
		e.perimeter(side);
		s.close();

	}

}
