package Programs;

import java.util.Scanner;

// 19. Perimeter Of Rhombus
public class RhombusPerimeter19 {

	private void perimeter(double s) {
		double per;
		per= (4*s);
		System.out.println();
		System.out.println("Perimeter of Rhombus : "+ per);

	}

	public static void main(String[] args) {

		double side;

		System.out.println("Enter the side: ");

		// Create Scanner object
		Scanner s = new Scanner(System.in);

		side = s.nextDouble();

		RhombusPerimeter19	r= new RhombusPerimeter19();
		r.perimeter(side);
		s.close();

	}



}
