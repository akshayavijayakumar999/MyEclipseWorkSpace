package Programs;

import java.util.Scanner;

//Java Program to Convert Character to String and Vice-Versa
//Java Program to convert char type variables to int
//Java Program to convert int type variables to char
//Java Program to convert long type variables into int
//Java Program to convert int type variables to long
//Java Program to convert boolean variables into string
//Java Program to convert string type variables into boolean
//Java Program to convert string type variables into int
//Java Program to convert int type variables to String
//Java Program to convert int type variables to double
//Java Program to convert double type variables to int
//Java Program to convert string variables to double
//Java Program to convert double type variables to string
//Java Program to convert primitive types to objects and vice versa

public class Conversion6 {

	//Java Program to Convert Character to String and Vice-Versa
	public void  chartoString(char ch) {
		System.out.println("1. Character To String");
		System.out.println("Character: "+ch);
		String s = Character.toString(ch);
		System.out.println("String: " + s);
		System.out.println();
	}


	public void  stringtoChar(String s) { 

		System.out.println("1. String to Character");
		System.out.println("String: " + s);
		for(int i=0; i<s.length();i++){  
			char ch = s.charAt(i);  
			System.out.println("character "+i+" = "+ch);  
			System.out.println();
		}   

	}//close chartoString(String s)

	//Java Program to convert char type variables to int

	public void chartoInt(char ch)
	{

		System.out.println("3. Character To Int");
		System.out.println("Character: " + ch);
		// Converting ch to it's int value
		int n = ch - '0';
		System.out.println("int: " + n);
		System.out.println();
	}

	// Java Program to convert int type variables to char

	public void inttoChar(int n)
	{
		System.out.println("4. Int To Character");
		System.out.println("Integer : "+n); 

		if(n>=0&&n<=9)
		{
			char c = Character.forDigit(n, 10); //if the int value is between 0 to 9, we use 10 
			System.out.println("Characer : "+c); 

		}

		if(n>=10&&n<=15)
		{
			char c = Character.forDigit(n, 15); //if the int value is between 0 to 15, we use 16,
			System.out.println("Characer : "+c);
		}
		System.out.println();
	}
	//Java Program to convert long type variables into int

	public void longtoInt(long l) {

		System.out.println("5. Long To Int");
		System.out.println("Long : "+l);
		int n=(int)l;  
		System.out.println("Integer : "+n);  
		System.out.println();
	}

	// Java Program to convert int type variables to long

	public void inttoLong(int n) {

		System.out.println("6. Int To Long");
		System.out.println("Integer : "+n);	 
		//long l=n;  	
		Long l=Long.valueOf(n);// calling Long.valueOf() method
		System.out.println("Long : "+l);  
		System.out.println();
	}

	// Java Program to convert boolean variables into string
	public void booleantoString(boolean b) {

		System.out.println("7. Boolean To String");
		System.out.println("Boolean : "+b);	 
		String s=String.valueOf(b);  
		System.out.println("String : "+s);  
		System.out.println();
	}
	// Java Program to convert string type variables into boolean	

	public void stringtoBoolean(String s) {

		System.out.println("8. String To Boolean");
		System.out.println("String : "+s); 
		boolean b=Boolean.parseBoolean(s);  
		System.out.println("Boolean : "+b);
		System.out.println();
	}

	// Java Program to convert string type variables into int

	public void stringtoInt(String s) {

		System.out.println("9. String To Int");
		System.out.println("String : "+s); 
		int n=Integer.parseInt(s);  
		System.out.println("Integer : "+n);
		System.out.println();
	}
	//java Program to convert int type variables to String  

	public void inttoString(int n) {
		System.out.println("10. Int To String");
		System.out.println("Integer : "+n);
		String s=Integer.toString(n);  
		System.out.println("String : "+s); 
		System.out.println();
	}

	//Java Program to convert int type variables to double
	public void inttoDouble(int n) {

		System.out.println("11. Int To Double");
		System.out.println("Integer : "+n);
		Double d=Double.valueOf(n);  
		System.out.println("Double : "+d); 
		System.out.println();
	}

	// Java Program to convert double type variables to int
	public void doubletoInt(double d)
	{

		System.out.println("12. Double To Int");
		System.out.println("Double : "+d); 
		int n=(int)d;    
		System.out.println("Integer : "+n);	
		System.out.println();
	}

	// Java Program to convert string variables to double
	public void stringtoDouble(String s)
	{

		System.out.println("13. String To Double");
		System.out.println("String : "+s); 
		double d = Double.parseDouble(s);     
		System.out.println("Double : "+d);	
		System.out.println();
	}

	//Java Program to convert double type variables to string

	public void doubletoString(double d)
	{

		System.out.println("14. Double To String");
		System.out.println("Double : "+d);	
		String s=Double.toString(d);     
		System.out.println("String : "+s); 
		System.out.println();
	}
	public static void main(String args[]){ 

		int n;
		char c;
		Conversion6	obj =new Conversion6();
		Scanner s = new Scanner(System.in);

		do {
			System.out.println("1. Character To String");
			System.out.println("2 String To Character");
			System.out.println("3. Character To Int");
			System.out.println("4. Int To Character");
			System.out.println("5. Long To Int");
			System.out.println("6. Int To Long");
			System.out.println("7. Boolean To String");
			System.out.println("8. String To Boolean");
			System.out.println("9. String To Int");
			System.out.println("10. Int To String");
			System.out.println("11. Int To Double");
			System.out.println("12. Double To Int");
			System.out.println("13. String To Double");
			System.out.println("14. Double To String");
			System.out.println("Select your choice : ");
			n = s.nextInt();
			switch(n)
			{

			case 1:
				obj.chartoString('a');
				break;

			case 2:
				obj.stringtoChar("hai");
				break;

			case 3:
				obj.chartoInt('t');
				break;

			case 4:
				obj.inttoChar(10);
				break;

			case 5:
				obj.longtoInt(100);
				break;

			case 6:
				obj.inttoLong(1);
				break;

			case 7:
				obj.booleantoString(true);
				break;
			case 8:
				obj.stringtoBoolean("true");
				break;

			case 9:
				obj.stringtoInt("200");
				break;

			case 10:
				obj.inttoString(89);
				break;

			case 11:
				obj.inttoDouble(9);
				break;

			case 12:
				obj.doubletoInt(499.00);
				break;

			case 13:
				obj.stringtoDouble("999");
				break;

			case 14:
				obj.doubletoString(999.0);
				break;	

			default:System.out.println("Invalid Choice");
			}

			System.out.println("Do you want to continue?(Y/N): ");	
			c=s.next().charAt(0);   
		}
		while(c=='y'||c=='Y');
		s.close();
	}


}
