package Programs;
//Swap two numbers without using temporary variable

public class Swap3 {

	public static void main(String[] args) {

		float first = 2.30f, second = 8.95f;

		System.out.println("Before swap");
		System.out.println("First number : " + first);
		System.out.println("Second number : " + second);

		first = first + second; 
		second = first - second; 
		first = first - second;  //Swap two numbers without using temporary variable

		System.out.println();

		System.out.println("After swap");
		System.out.println("First number : " + first);
		System.out.println("Second number : " + second);

	}
}