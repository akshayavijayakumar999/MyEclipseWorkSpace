package Programs;

import java.util.Scanner;

// Program to implement calculator
public class Calculator27 {
	public static void main(String[] args) {

		int n,n1,n2,s1,d,p;
		char c;

		// Create Scanner object
		Scanner s = new Scanner(System.in);
		do {
			System.out.println("CALCULATOR");
			System.out.println("1. ADDITION");
			System.out.println("2. SUBTRACTION");
			System.out.println("3. MULTIPLICATION");
			System.out.println("4. DIVISION");
			System.out.println("SELECT YOUR CHOICE : ");
			n = s.nextInt();
			System.out.println("Enter the two numbers: ");
			n1 = s.nextInt();
			n2 = s.nextInt();
			switch(n)
			{
			case 1:
				s1=n1+n2;
				System.out.println("Sum: " +s1);
				break;
			case 2:
				d=n1-n2;
				System.out.println("Differencem: " +d);
				break;
			case 3:
				p=n1*n2;
				System.out.println("Differencem: " +p);
				break;
			case 4:
				d=n1/n2;
				System.out.println("Differencem: " +d);
				break;
			default:System.out.println("Invalid Choice");
			}

			System.out.println("Do you want to continue?(Y/N): ");	
			c=s.next().charAt(0);   
		}
		while(c=='y'||c=='Y');
		s.close();

	}
}
