package Programs;

import java.util.Scanner;

// 17. Perimeter Of Rectangle
public class RectanglePerimeter17 {
	
	public void perimeter(double l,double b) // Function to find the area
	{
		double perimeter;
		perimeter= (2*(l+b));
		System.out.println();
		System.out.println("Perimeter of Rectangle : "+ perimeter);
	}

	
	public static void main(String[] args) {
		double length,breadth;

		// Input the length
		System.out.println("Enter the length: ");
		
		// Create Scanner object
		Scanner s = new Scanner(System.in);

		// Read the next Double from the screen
		length = s.nextDouble();

		System.out.println("Enter the breadth: ");
		breadth = s.nextDouble();

		RectanglePerimeter17	r= new RectanglePerimeter17();
		r.perimeter(length,breadth);
		s.close();

	}

}
