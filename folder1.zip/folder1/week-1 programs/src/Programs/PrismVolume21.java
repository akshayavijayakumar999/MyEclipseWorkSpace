package Programs;

import java.util.Scanner;

public class PrismVolume21 {
	
	public void volume(double a,double b,double h) // Function to find the Volume
	{
		double vol;
		vol= (a*b*h)/2;
		System.out.println();
		System.out.println("Volume Of prism : "+ vol);
	}

	public static void main(String[] args) {
		double apothem,base,height;

		// Create Scanner object
		Scanner s = new Scanner(System.in);
		
		System.out.println("Enter the apothem length of the prism: ");
		apothem = s.nextDouble();
		
		System.out.println("Enter the base length of the prism: ");
		base = s.nextDouble();

		System.out.println("Enter the height of the prism: ");
		height = s.nextDouble();

		PrismVolume21 p= new PrismVolume21();
		p.volume(apothem,base,height);

		s.close();
	}
}
