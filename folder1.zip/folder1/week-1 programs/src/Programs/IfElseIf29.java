package Programs;

import java.util.Scanner;

// check a number is  by zero or greater than zero or less than zero

public class IfElseIf29 {
	public static void main(String[] args) {

		// Create Scanner object
		Scanner s = new Scanner(System.in);
		System.out.println("Enter the number: ");
		int n = s.nextInt();

		if (n<0) {

			System.out.println("The entered number " + n +" is less than Zero");
		}

		else if (n>0)
		{
			System.out.println("The entered number " + n +" is greater than Zero");
		}
		else {
			System.out.println("The entered number is zero");
		}

		s.close();


	}
}