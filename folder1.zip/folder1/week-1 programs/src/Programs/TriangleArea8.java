package Programs;

import java.util.Scanner;
// 8. Area Of Triangle

public class TriangleArea8 {
	public void area(double a,double b,double c) // Function to find the area
	{
		double s1=(a+b+c)/2;
		double area=Math.sqrt(s1*(s1-a)*(s1-b)*(s1-c)) ;
		System.out.println();
		System.out.println("Area of Triangle : "+ area);
	}

	public static void main(String[] args) {
		double a,b,c;

		Scanner s = new Scanner(System.in);
		// Input the sides
		System.out.println("Enter the 3 sides of the Triangle: ");
		a = s.nextDouble();
		b = s.nextDouble();
		c = s.nextDouble();

		TriangleArea8 t =new TriangleArea8();
		t.area(a,b,c);
		s.close();
	}
}
