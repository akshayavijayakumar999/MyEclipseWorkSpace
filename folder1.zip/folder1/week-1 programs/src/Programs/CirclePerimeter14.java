package Programs;

import java.util.Scanner;

// 14. Perimeter Of Circle

public class CirclePerimeter14 {

	public void perimeter(double r) // Function to find the perimeter
	{
		double perimeter;
		perimeter= ((2*3.14)*r);
		System.out.println();
		System.out.println("Perimeter of Circle : "+ perimeter);

	}

	public static void main(String[] args) {
		double radius;

		// Input the radius
		System.out.println("Enter the radius: ");

		// Create Scanner object
		Scanner s = new Scanner(System.in);

		// Read the next integer from the screen
		radius = s.nextDouble();

		CirclePerimeter14	c= new CirclePerimeter14();
		c.perimeter(radius);
		s.close();

	}
}
