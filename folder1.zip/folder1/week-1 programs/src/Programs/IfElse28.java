package Programs;

import java.util.Scanner;

public class IfElse28 {
	// check a number is divisible by 2 and 4

	public static void main(String[] args) {

		// Create Scanner object
		Scanner s = new Scanner(System.in);
		System.out.println("Enter the number: ");
		int n = s.nextInt();

		// checks if number divisible by 4 and 2
		if (((n%2)==0) &((n%4)==0)) {

			System.out.println("The number " + n +" is divisible by 2 and 4.");
		}

		// execute this block
		// if number is not divisible by 2 and 4
		else {
			System.out.println("The number is not " + n +" is divisible by 2 and 4.");
		}

		s.close();
	}

}
