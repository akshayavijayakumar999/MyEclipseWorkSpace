package Programs;

import java.util.Scanner;

// 20. Volume Of Cone Java Program
public class ConeVolume20 {
	public void volume(double r,double h) // Function to find the Volume
	{
		double vol;
		vol= (3.14*r*r*h)/3;
		System.out.println();
		System.out.println("Volume Of Cone : "+ vol);
	}
	
	public static void main(String[] args) {
		double radius,height;

		System.out.println("Enter the base radius of the cone: ");

		// Create Scanner object
		Scanner s = new Scanner(System.in);

		radius = s.nextDouble();
		System.out.println("Enter the height of the cone: ");
		
		height = s.nextDouble();
		
		ConeVolume20 c= new ConeVolume20();
		c.volume(radius,height);

		s.close(); 
	}

}
