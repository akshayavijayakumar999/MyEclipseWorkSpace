package Programs;

import java.util.Scanner;

//9. Area Of Rectangle Program

public class RectangleArea9 {

	public void area(double l,double b) // Function to find the area
	{
		double area;
		area= l*b;
		System.out.println();
		System.out.println("Area of Rectangle : "+ area);
	}

	public static void main(String[] args) {
		double length,breadth;

		// Input the length
		System.out.println("Enter the length: ");
		
		// Create Scanner object
		Scanner s = new Scanner(System.in);

		// Read the next integer from the screen
		length = s.nextDouble();

		System.out.println("Enter the breadth: ");
		breadth = s.nextDouble();

		RectangleArea9	r= new RectangleArea9();
		r.area(length,breadth);

		s.close();
	}
}
