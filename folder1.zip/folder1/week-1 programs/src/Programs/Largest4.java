package Programs;

public class Largest4 {
// 4. Java Program to Find the Largest Among Three Numbers
	public int largest(int a,int b,int c)// Function to find the largest
	{ 
		int l;

		if(a>b)
			l=a;
		else
			l=b;
		
		if (c>l)
			l=c;

		return l;
	}

	public static void main(String[] args) {

		int largest;
		int a=3,b=4,c=0;

		Largest4 obj = new Largest4();
		largest=obj.largest(a, b, c);

		System.out.println("Largest number among "+a+","+b+","+c+" : " + largest);

	}
}
