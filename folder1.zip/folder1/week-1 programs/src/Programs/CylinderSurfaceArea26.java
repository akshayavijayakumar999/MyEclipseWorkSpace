package Programs;

import java.util.Scanner;
// 26. Total Surface Area Of Cylinder

public class CylinderSurfaceArea26 {

	// 26. Total Surface Area Of Cylinder
	public void surfaceArea(double r,double h) // Function to find the Surface Area
	{
		double area;
		area= ((2*3.14*r*h)+(2*3.14*r*r));
		System.out.println();
		System.out.println("Total Surface Area Of Cylinder : "+ area);
	}
	public static void main(String[] args) {

		double radius,height;

		// Create Scanner object
		Scanner s = new Scanner(System.in);
		
		System.out.println("Enter the base radius of the Cylinder: ");
		radius = s.nextDouble();

		System.out.println("Enter the height of the Cylinder: ");
		height = s.nextDouble();
		
		CylinderSurfaceArea26 c= new CylinderSurfaceArea26();
		
		c.surfaceArea(radius,height);

		s.close();
	}
}


