package Programs;

import java.util.Scanner;

// 16. Perimeter Of Parallelogram
public class ParallelogramPerimeter16 {

	public void perimeter(double a1,double a2) // Function to find the Perimeter
	{
		double perimeter;
		perimeter= (2*(a1+a2));
		System.out.println();
		System.out.println("Perimeter of Parallelogram : "+ perimeter);
	}

	public static void main(String[] args) {
		double adj1,adj2;

		// Input the length
		System.out.println("Enter the Adjacent side 1: ");

		// Create Scanner object
		Scanner s = new Scanner(System.in);

		// Read the next Double from the screen
		adj1 = s.nextDouble();

		System.out.println("Enter the Adjacent side 2: ");
		adj2 = s.nextDouble();

		ParallelogramPerimeter16 p= new ParallelogramPerimeter16();
		p.perimeter(adj1,adj2);
		s.close();

	}
}
