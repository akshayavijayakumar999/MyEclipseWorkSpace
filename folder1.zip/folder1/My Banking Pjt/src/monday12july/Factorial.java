package monday12july;

import java.util.Scanner;

public class Factorial {
	
		public static void main(String args[]){ 

			int fact=1;
			int i;
			Scanner s = new Scanner(System.in);
			System.out.println("Enter Your Number: ");
			
			int n= s.nextInt();
			for(i=1;i<=n;i++){    
				fact=fact*i;    
			} 
			System.out.println("Factorial of number "+n+" is : " +fact);
			s.close();
		}
	}


