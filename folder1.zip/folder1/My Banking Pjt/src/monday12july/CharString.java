package monday12july;

import java.util.Scanner;
// How to convert char to String in Java
public class CharString {
	
	
		public static void main(String args[])  
		{ 
			Scanner sc=new Scanner(System.in);  
			System.out.print("Enter the Character: ");  
			char ch = sc.next().charAt(0); 
			System.out.println("Character To String");
			System.out.println("Character: "+ch);
			String s = Character.toString(ch);
			System.out.println("String: " + s);
			System.out.println();
			sc.close();
			
	}
}
