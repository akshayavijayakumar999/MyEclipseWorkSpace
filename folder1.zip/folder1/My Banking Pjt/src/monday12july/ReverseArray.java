package monday12july;
//  Java Program to print the elements of an array in reverse order

import java.util.Scanner;

public class ReverseArray {

	public static void main(String args[])  
	{
		int a[];
		int i;
		Scanner sc=new Scanner(System.in);  
		System.out.print("Enter the limit of the array: ");  
		int n = sc.nextInt();
		a= new int[n];  
		System.out.print("Enter the Elements of the array: ");
		for(i=0;i<n;i++)
		{

			a[i]=sc.nextInt();
		}
		System.out.print("Reversed array: ");
		for( i=(a.length-1);i>=0;--i)                
		{  
			System.out.println(a[i]);           
		}
		sc.close();
	}
}
