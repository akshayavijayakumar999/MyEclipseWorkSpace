package bankpkg;

public interface BankingInterface {
	void display();
	

}
