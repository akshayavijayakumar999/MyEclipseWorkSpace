package junitPkg;

import java.util.Scanner;

import org.junit.Test;


public class ParallelogramArea {
//	public void area(double b,double h) // Function to find the area
//	{
//		double area;
//		area= b*h;
//		System.out.println();
//		System.out.println("Area of Parallelogram : "+ area);
//	}
//	
//	public static void main(String[] args) {
//		double base,height;
//
//		// Input the base
//		System.out.println("Enter the base: ");
//		
//		// Create Scanner object
//		Scanner s = new Scanner(System.in);
//
//		// Read the next Double from the screen
//		base = s.nextDouble();
//
//		System.out.println("Enter the height: ");
//		height = s.nextDouble();
//
//		ParallelogramArea	p= new ParallelogramArea();
//		p.area(base,height);
//		s.close();
//
//	}

	@Test
	void test()
	{
		System.out.println("Enter the height: ");
	}
}
