package junitPkg;

import org.junit.runner.JUnitCore;
import org.junit.runner.notification.RunListener;

public class Test1Imp {
	public static void main(String[] args) {
	JUnitCore core= new JUnitCore();
    core.addListener(new RunListener());
    core.run(Largest.class);
}
}