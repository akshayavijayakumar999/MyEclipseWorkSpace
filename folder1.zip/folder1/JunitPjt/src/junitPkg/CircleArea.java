package junitPkg;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class CircleArea {
	public static double area(double r) // Function to find the area
	{
		double area;
		area= 3.14 *r*r;
		System.out.println();
		System.out.println("Area of Circle : "+ area);
		return area;

	}
	
	@Test
	void test() {
		assertEquals(0, CircleArea.area(0));
	}

}
