package junitPkg;

import static org.junit.Assert.*;

import org.junit.Test;

public class R {

	@Test
	public void test() {
		assertEquals(1,2);
	}

}
