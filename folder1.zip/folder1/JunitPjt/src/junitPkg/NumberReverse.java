package junitPkg;

import static org.junit.Assert.*;

import java.util.Scanner;

import org.junit.Test;

public class NumberReverse {

	@Test
	public void test() {
		int n;
		int l,r=0;
		Scanner s = new Scanner(System.in);
        System.out.println("Enter the number : ");
        n = s.nextInt();
        
        while(n>0)
        {
        l=n % 10;
        r=((r*10)+l);
        n=n/10;
        }
        System.out.println("Reversed Number: "+r);
        
        s.close();
	}

}
