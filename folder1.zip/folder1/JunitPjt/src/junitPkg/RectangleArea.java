package junitPkg;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class RectangleArea {
	
	public static double area(double l,double b) // Function to find the area
	{
		double area;
		area= l*b;
		System.out.println();
		System.out.println("Area of Rectangle : "+ area);
		return area;
	}
	@Test
	void test() {
		assertEquals(0, RectangleArea.area(0,0));
	}

}
