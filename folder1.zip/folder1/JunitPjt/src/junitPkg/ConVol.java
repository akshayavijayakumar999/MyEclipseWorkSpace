package junitPkg;

import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Test;

public class ConVol {
	
	public static double volume(double r,double h) // Function to find the Volume
	{
		double vol;
		vol= (3.14*r*r*h)/3;
		System.out.println();
		System.out.println("Volume Of Cone : "+ vol);
		return vol;
	}
	

	@Test
	public void test() {
		assertEquals(0,ConVol.volume(1, 1) );
	}

}
