package junitPkg;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class CubeSurfaceArea {
	public static double surfaceArea(double s) // Function to find the Surface Area
	{
		double area;
		area= (6*s*s);
		System.out.println();
		System.out.println("Curved Surface Area Of Cube : "+ area);
		return area;
	}

	@Test
	void test() {
		assertEquals(0, CubeSurfaceArea.surfaceArea(0));
	}

}
