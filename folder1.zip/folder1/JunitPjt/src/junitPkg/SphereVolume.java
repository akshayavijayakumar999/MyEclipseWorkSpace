package junitPkg;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class SphereVolume {
	public static double volume(double r) // Function to find the Volume
	{
		double vol;
		vol= (4*3.14*r*r*r)/3;
		System.out.println();
		System.out.println("Volume Of Sphere : "+ vol);
		return vol;
	}
	
	@Test
	void test() {
		assertNotEquals(0,SphereVolume.volume(0));
	}

}
