package junitPkg;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class AssertDiff {

	@Test
	void test() {
		String string1="Junit";					
        String string2="Juiit";					
        String string3="test";					
        String string4="test";
        int a=1;
        int b=1;
        
       // assertEquals(a,b);	
        assertEquals(string1,string2);					
       // assertSame(a, b);	
	}

}
