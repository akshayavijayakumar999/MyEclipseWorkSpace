package junitPkg;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Scanner;

import org.junit.jupiter.api.Test;

class StringReverse {

	@Test
	void test() {
		String s, reverse = "";
	    Scanner scan = new Scanner(System.in);

	    System.out.println("Enter a string to reverse: ");
	    s = scan.nextLine();

	    int length = s.length();

	    for (int i = length - 1 ; i >= 0 ; i--)
	      reverse = reverse + s.charAt(i);

	    System.out.println("Reverse of the string: " + reverse);
	    scan.close();
	    assertEquals(s,reverse);
	}

}
