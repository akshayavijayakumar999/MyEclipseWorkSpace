package junitPkg;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Scanner;

import org.junit.jupiter.api.Test;

class Largest {
	
	public static int largest(int a,int b,int c)// Function to find the largest
	{ 
		int l;
		
		if(a>b)
			l=a;
		else
			l=b;
		
		if (c>l)
			l=c;

		return l;
	}


	@Test
	void test() {
		Scanner s = new Scanner(System.in);
		int a,b,c;
		System.out.println("Enter the numbers");
		a=s.nextInt();
		b=s.nextInt();
		c=s.nextInt();
		 assertEquals(5,Largest.largest(a, b, c));  	
	}

}
